document.addEventListener("DOMContentLoaded", () => {

  // 🔄 Ping inicial oculto para precalentar el modelo y evitar error en el primer mensaje
  fetch("/api/chat", {
    method: "POST",
    body: new URLSearchParams({ user_input: "ping_inicial_oculto" }),
    headers: { "Content-Type": "application/x-www-form-urlencoded" }
  }).catch(err => console.warn("Ping inicial falló:", err));

  const chatForm = document.getElementById("chatForm");
  const input = document.getElementById("user_input");
  const chatBox = document.getElementById("chatBox");
  const audio = document.getElementById("notificationSound");
  const micBtn = document.getElementById("micBtn");
  const clearBtn = document.getElementById("clearChatBtn"); // botón de nueva conversación

  function renderUserMessage(text) {
    const userMsg = document.createElement("div");
    userMsg.className = "message user";
    userMsg.innerHTML = `<strong>Tú:</strong> ${text}`;
    chatBox.appendChild(userMsg);
  }

  function renderThorMessage(htmlContent) {
    const wrapper = document.createElement("div");
    wrapper.className = "message bot";

    const avatar = document.createElement("img");
    avatar.className = "avatar-thor";
    avatar.alt = "Thor";
    avatar.src = "/static/avatar.jpeg";

    const bubble = document.createElement("div");
    bubble.className = "bubble bot-bubble";

    const sender = document.createElement("div");
    sender.className = "sender";
    sender.textContent = "Thor";

    const content = document.createElement("div");
    content.className = "content";
    content.innerHTML = htmlContent;

    // Botón de voz
    const ttsBtn = document.createElement("button");
    ttsBtn.className = "tts-btn";
    ttsBtn.innerHTML = "🔊";
    ttsBtn.title = "Reproducir mensaje";
    ttsBtn.onclick = () => speakThor(ttsBtn);

    bubble.appendChild(sender);
    bubble.appendChild(content);
    bubble.appendChild(ttsBtn);

    wrapper.appendChild(avatar);
    wrapper.appendChild(bubble);

    chatBox.appendChild(wrapper);
  }

  function scrollEnd() {
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    // detener voz si está hablando
    speechSynthesis.cancel();
    document.querySelectorAll(".tts-btn").forEach(btn => btn.textContent = "🔊");

    const userText = input.value.trim();
    if (!userText) return;

    renderUserMessage(userText);
    scrollEnd();

    const formData = new FormData();
    formData.append("user_input", userText);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) throw new Error("La respuesta del servidor falló.");

      const data = await response.json();
      renderThorMessage(data.reply);

      if (audio) {
        try { audio.play(); } catch (_) {}
      }
      scrollEnd();
    } catch (err) {
      console.error("Error:", err);
      renderThorMessage("😓 Ups... algo salió mal. ¿Quieres intentar de nuevo o comenzar una nueva conversación?");
      scrollEnd();
    } finally {
      input.value = "";
      input.focus();
    }
  });

  // 🎤 Reconocimiento de voz
  if ("SpeechRecognition" in window || "webkitSpeechRecognition" in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = "es-ES";
    recognition.interimResults = false;

    micBtn.addEventListener("click", () => {
      recognition.start();
      micBtn.textContent = "🎙️";
    });

    recognition.onresult = (event) => {
      // Añadir en lugar de reemplazar
      input.value += (input.value ? " " : "") + event.results[0][0].transcript;
      micBtn.textContent = "🎤";
    };

    recognition.onerror = () => { micBtn.textContent = "🎤"; };
    recognition.onend = () => { micBtn.textContent = "🎤"; };
  } else {
    micBtn.disabled = true;
    micBtn.title = "Tu navegador no soporta reconocimiento de voz";
  }

  // 🔊 Lectura de texto con control de pausa/detener
  function speakThor(btn) {
    if (speechSynthesis.speaking) {
      speechSynthesis.cancel();
      btn.textContent = "🔊";
      return;
    }

    const messageText = btn.closest(".bubble").querySelector(".content").innerText;
    const cleanText = messageText.replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu, "");

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = "es-ES";
    utterance.pitch = 0.6;
    utterance.rate = 0.9;

    const voices = speechSynthesis.getVoices();
    const selectedVoice = voices.find(
      v => v.lang.startsWith("es") && /male|hombre|raul|jorge/i.test(v.name)
    );
    if (selectedVoice) utterance.voice = selectedVoice;

    btn.textContent = "⏸️";
    utterance.onend = () => {
      btn.textContent = "🔊";
    };

    speechSynthesis.speak(utterance);
  }

  speechSynthesis.onvoiceschanged = () => {
    speechSynthesis.getVoices();
  };

  // 🆕 Detener voz al iniciar nueva conversación
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      speechSynthesis.cancel();
      document.querySelectorAll(".tts-btn").forEach(btn => btn.textContent = "🔊");
    });
  }
});
