from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from datetime import timedelta
import requests
import re
import markdown2
import json
from collections import defaultdict
import os

app = Flask(__name__)
app.secret_key = 'thor_uteg_secret'
app.permanent_session_lifetime = timedelta(minutes=30)

# 🔐 CONFIGURA TU API KEY DE FIREWORKS AQUÍ
FIREWORKS_API_KEY = "fw_3Zg9HqpDe5TJiPfQmjQwXcci"

# Ruta del archivo de menciones persistente
MENCIONES_JSON = "menciones_carreras.json"

# Cargar historial de menciones desde el archivo (si existe)
if os.path.exists(MENCIONES_JSON):
    with open(MENCIONES_JSON, "r", encoding="utf-8") as f:
        carrera_contador = defaultdict(int, json.load(f))
else:
    carrera_contador = defaultdict(int)

# Lista de todas las carreras reconocidas
CARRERAS = [
    "robótica e inteligencia artificial", "seguridad industrial", "psicología", "nutrición y dietética",
    "mercadotecnia", "administración de empresas", "ingeniería ambiental", "comercio exterior",
    "gestión del talento humano", "ingeniería industrial", "derecho", "ciberseguridad", "finanzas",
    "economía", "comunicación", "logística y transporte", "software", "sistemas de información",
    "contabilidad y auditoría", "educación básica", "puertos y aduanas", "relaciones internacionales",
    "gestión social y desarrollo", "pedagogía técnica de la mecatrónica", "multimedia y producción audiovisual",
    "gestión de riesgos y desastres", "electricidad", "telecomunicaciones"
]

SYSTEM_PROMPT = """
Eres Thor, un tigre amistoso, mascota oficial de la Universidad Tecnológica Empresarial de Guayaquil (UTEG).
Usa emojis, actúa como un tigre y formatea tu texto con negritas, cursiva o subrayado si es necesario para darle vida y hacerlo interesante.
Tu misión es guiar a estudiantes de colegio, responder dudas educativas, y explicar por qué estudiar en UTEG es una gran decisión.
Hablas con energía motivadora. Usa modismos ecuatorianos, pero educados.
Refiere a los estudiantes a la pagina web, en caso de que te estén pidiendo información que no tengas: "https://www.uteg.edu.ec/".
Servicios con los que contamos: Gimnasio, Cancha de fútbol/basketball/volleyball, 2 bares (uno en la terraza en quinto piso y otro junto a la cancha), Biblioteca, Laboratorios, Consejería Estudiantil, Ayuda Financiera, Seguro Estudiantil, Vinculación, Atención Médica, Becas deportivas, Pensión Diferenciada, Repositorio Digital.
La universidad, además, cuenta con un convenio con la Miami Business Technological University, que permite a los estudiantes de UTEG acceder a certificados internacionales en diversas áreas.
La universidad está ubicada en: Av. del bombero, Km. 6.5, Guayaquil – Ecuador. Y se puede contactar a los números: 0994139979, 0959241608, 0986683531.
Las carreras en modalidad presencial son: Robótica e Inteligencia Artificial, Seguridad Industrial, Psicología, Nutrición y Dietética, Mercadotecnia, Administración de Empresas, Ingeniería Ambiental, Comercio Exterior, Gestión del Talento Humano, Ingeniería Industrial, Derecho. En modalidad online son: Ciberseguridad, Finanzas, Administración de Empresas, Mercadotecnia, Comercio Exterior, Economía, Comunicación, Logística y Transporte, Software, Sistemas de Información, Contabilidad y Auditoría, Gestión del Talento Humano, Educación Básica, Puertos y Aduanas, Relaciones Internacionales, Gestión Social y Desarrollo, Pedagogía Técnica de la Mecatrónica, Multimedia y Producción Audiovisual, Gestión de Riesgos y Desastres, Derecho. En modalidad híbridas son: Electricidad, Software, Telecomunicaciones.
"""

@app.route('/')
def index():
    if not session.get('chat'):
        session['chat'] = []
    return render_template('index.html', chat=session['chat'])

@app.route('/clear', methods=['POST'])
def clear_chat():
    session.pop('chat', None)
    return redirect(url_for('index'))

@app.route('/api/chat', methods=['POST'])
def api_chat():
    try:
        user_input = request.form.get('user_input', '').strip()

        # 🛠 Ping inicial oculto para precalentar el modelo
        if user_input == "ping_inicial_oculto":
            return jsonify({"reply": ""})

        if "carrera más mencionada" in user_input.lower() or "de la que más te han hablado" in user_input.lower():
            if carrera_contador:
                carrera_mas = max(carrera_contador, key=carrera_contador.get)
                veces = carrera_contador[carrera_mas]
                respuesta = f"La carrera más mencionada hasta ahora es **{carrera_mas.title()}**, con {veces} {'mención' if veces == 1 else 'menciones'}. 📊"
            else:
                respuesta = "Aún no he recibido suficientes preguntas sobre carreras como para darte un dato. ¡Pregunta tú primero! 😄"
            return jsonify({"reply": markdown2.markdown(respuesta)})

        if not user_input:
            return jsonify({"reply": "😅 No entendí tu pregunta. ¿Puedes intentarlo otra vez?"})

        texto = user_input.lower()
        for carrera in CARRERAS:
            if carrera in texto:
                carrera_contador[carrera] += 1

        with open(MENCIONES_JSON, "w", encoding="utf-8") as f:
            json.dump(carrera_contador, f, indent=2, ensure_ascii=False)

        session.setdefault('chat', [])
        last_turns = session['chat'][-6:]

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ] + [
            {"role": "user" if sender == "Tú" else "assistant", "content": msg}
            for sender, msg in last_turns
        ] + [
            {"role": "user", "content": user_input}
        ]

        url = "https://api.fireworks.ai/inference/v1/chat/completions"
        payload = {
            "model": "accounts/fireworks/models/llama-v3p3-70b-instruct",
            "max_tokens": 2048,
            "temperature": 0.6,
            "top_p": 1,
            "top_k": 40,
            "presence_penalty": 0,
            "frequency_penalty": 0,
            "messages": messages
        }
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {FIREWORKS_API_KEY}"
        }

        response = requests.post(url, headers=headers, data=json.dumps(payload))
        data = response.json()
        raw_reply = data['choices'][0]['message']['content'].strip()
        cleaned = re.sub(r"<think>.*?</think>", "", raw_reply, flags=re.DOTALL).strip()
        reply = markdown2.markdown(cleaned)

        session['chat'].append(('Tú', user_input))
        session['chat'].append(('Thor', reply))
        session.modified = True

        return jsonify({"reply": reply})

    except Exception as e:
        print("❌ Error en la API:", e)
        return jsonify({"reply": "😓 Algo falló en el servidor. Intenta otra vez o inicia una nueva conversación."})

if __name__ == '__main__':
    app.run(debug=True)
